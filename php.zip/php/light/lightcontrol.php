<?php
$x=$_GET['q'];
$conn=mysqli_connect('localhost','hello','','smarthome');
$sql="insert into light(status) values('$x')";
$q=mysqli_query($conn, $sql);
if ($x=="true"){
system("sudo python ../python/gardenlight/gardenlighton.py &");
system("sudo python ../python/lcd/lcddisplay.py gardenlight on &");
}elseif ($x=="false"){
system("sudo python ../python/gardenlight/gardenlightoff.py &");
system("sudo python ../python/lcd/lcddisplay.py gardenlight off &");
}
else{}
?>

<?php
$conn=mysqli_connect('localhost','hello','','smarthome');
$sql="select status from light order by date desc limit 1";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result)>0)
{
    // output data of each row
    while($row = mysqli_fetch_assoc($result))
     {
        echo  $row["status"];

    }
}
?>

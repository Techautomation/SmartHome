<?php
$x=$_GET['q'];
$conn=mysqli_connect('localhost','hello','','smarthome');
$sql="insert into msensor(status) values('$x')";
$q=mysqli_query($conn, $sql);
if ($x=="true"){
system("sudo python ../python/msensor/msensoron.py &");
}elseif ($x=="false"){
system("sudo python ../python/msensor/msensoroff.py &");
}
else{}
?>

<?php
system('sudo python /var/www/html/python/auto/auto.py &');
?>

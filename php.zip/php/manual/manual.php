<?php
system('sudo python /var/www/html/python/manual/manual.py &');
?>

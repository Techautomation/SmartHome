<?php
system("sudo python /var/www/html/python/camera/cameraclick.py &");
?>


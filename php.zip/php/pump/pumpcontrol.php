<?php
$x=$_GET['q'];
$conn=mysqli_connect('localhost','hello','','smarthome');
$sql="insert into pump(status) values('$x')";
$q=mysqli_query($conn, $sql);
if ($x=="true"){
system("sudo python ../python/pump/pumpon.py &");
system("sudo python ../python/lcd/lcddisplay.py pump on &");
}elseif ($x=="false"){
system("sudo python ../python/pump/pumpoff.py &");
system("sudo python ../python/lcd/lcddisplay.py pump off &");
}
else{}
?>

<?php
$x=$_GET['q'];
$conn=mysqli_connect('localhost','hello','','smarthome');
$sql="insert into fan(status) values('$x')";
$q=mysqli_query($conn, $sql);
if ($x=="true"){
system("sudo python ../python/fan/fanon.py &");
system("sudo python ../python/lcd/lcddisplay.py fan on &");
}elseif ($x=="false"){
system("sudo python ../python/fan/fanoff.py &");
}
else{}
?>

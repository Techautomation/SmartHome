<?php
system("sudo python /var/www/html/python/onload/onload.py &");
?>

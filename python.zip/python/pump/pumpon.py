import RPi.GPIO as GPIO
import os
LedPin = 8    # pin8
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.HIGH) # Set LedPin high(+3.3V) to turn on led
print "pump on" # pump on
os.system("sudo python /email1.py 'Water Pump on!' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'Water pump on!' &")
os.system("sudo omxplayer /var/www/html/python/pump/pumpon.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py pump on &")



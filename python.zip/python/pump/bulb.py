import gtts
from gtts import gTTS

tts=gTTS(text='pump off!',lang='en',slow=True)
tts.save('pumpoff.mp3')


import RPi.GPIO as GPIO
import os
LedPin = 10    # pin10
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.HIGH) # Set LedPin high(+3.3V) to turn on led
print "pir on" # pir on
os.system("sudo python /email1.py 'P.I.R Sensors On!' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'P.I.R Sensor On!' &")
os.system("sudo omxplayer /var/www/html/python/pir/piron.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py pir on &")
os.system("sudo python ../python/pir/campir.py &")
os.system("sudo python ../python/pir/bulbpir.py &")



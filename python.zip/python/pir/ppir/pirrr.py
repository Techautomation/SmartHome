import RPi.GPIO as GPIO
import time
sensorpin=11
GPIO.setmode(GPIO.BOARD)
GPIO.setup(3,GPIO.OUT)
GPIO.setup(sensorpin,GPIO.IN)

def MotionDetected(sensorpin):
    print "motion detected"
    GPIO.output(3,1)
    time.sleep(3)
    GPIO.output(3,0)
time.sleep(2)
print "ready"
while True:
    GPIO.add_event_detect(sensorpin,GPIO.RISING,callback=MotionDetected)
    pass

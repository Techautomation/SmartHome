import RPi.GPIO as GPIO
import time
import sys
import os
home_sensor_pin=13
camera_sensor_pin=11
GPIO.setmode(GPIO.BOARD)
GPIO.setup(3,GPIO.OUT)
GPIO.setup(home_sensor_pin,GPIO.IN)
GPIO.setup(camera_sensor_pin,GPIO.IN)
cmd="sh cameraclick.sh"
def MotionDetected(home_sensor_pin):
    print "motion detected"
    GPIO.output(3,1)
    time.sleep(5)
    GPIO.output(3,0)
def MotionDetectedcamera(camera_sensor_pin):
    print "camera motion detected"
    os.system(cmd)


print "ready"
try:
    GPIO.add_event_detect(home_sensor_pin,GPIO.RISING,callback=MotionDetected)
#GPIO.add_event_detect(camera_sensor_pin,GPIO.RISING,callback=MotionDetectedCamera)
except:
    print "hj"
    os.system(cmd)


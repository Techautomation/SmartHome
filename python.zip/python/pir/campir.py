import RPi.GPIO as GPIO
import time
import datetime
import os ,sys
import MySQLdb
db=MySQLdb.connect('localhost','hello','','smarthome')
c=db.cursor()

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(27, GPIO.IN)         #Read output from PIR motion sensor
while True:
    i=GPIO.input(27)
    if i==0:                 #When output from motion sensor is LOW
        print "No intruders",i
        time.sleep(1)
    elif i==1:               #When output from motion sensor is HIGH
        print "Intruder detected",i
        os.system("sh /var/www/html/python/camera/cameraclick.sh")
	os.system("python ../lcd/lcddisplay.py 'Motion Detected [C] ' 'Image Saved! ' ")
	sql = "INSERT INTO pircamera(value)  \
        VALUES ('detected' );"  \
         # Execute the SQL command
        c.execute(sql)
        # Commit your changes in the database
        db.commit()
        time.sleep(4)
  




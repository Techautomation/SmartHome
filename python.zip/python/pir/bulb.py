import gtts
from gtts import gTTS

tts=gTTS(text='P.I.R sensor OFF!',lang='en',slow=True)
tts.save('piroff.mp3')


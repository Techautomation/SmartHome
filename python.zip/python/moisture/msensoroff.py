import RPi.GPIO as GPIO
LedPin = 11    # pin11
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.LOW) # Set LedPin high(+3.3V) to turn on led
print "msensor off" # msensor off

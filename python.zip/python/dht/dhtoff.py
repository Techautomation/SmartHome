import RPi.GPIO as GPIO
import os
LedPin =12     # pin 11
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.LOW) # Set LedPin high(+3.3V) to turn on led
print "dht off" # dht off
os.system("sudo python /email1.py 'Temprature Sensor off!' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'bulb-on' &")
os.system("sudo omxplayer /var/www/html/python/dht/dhtoff.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py dht off &")



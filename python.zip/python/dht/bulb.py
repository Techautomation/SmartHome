import gtts
from gtts import gTTS

tts=gTTS(text='Temprature sensor off',lang='en',slow=True)
tts.save('dhtoff.mp3')


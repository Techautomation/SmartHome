import gtts
from gtts import gTTS

tts=gTTS(text='Image clicked!',lang='en',slow=True)
tts.save('camclick.mp3')


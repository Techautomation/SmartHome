import os

os.system("sudo sh /var/www/html/python/camera/cameraclick.sh &")
os.system("sudo python /var/www/html/python/lcd/lcddisplay.py 'Image Saved' 'In Gallery' on &")
os.system("sudo omxplayer /var/www/html/python/camera/camclick.mp3 &");



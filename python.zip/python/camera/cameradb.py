import sys
import os 
import MySQLdb

db=MySQLdb.connect('localhost','hello','','smarthome')
c=db.cursor()

image=sys.argv[1]
sql = "INSERT INTO camera(status) \
VALUES ('%s' )" % \
(image)
         # Execute the SQL command
c.execute(sql)
        # Commit your changes in the database
db.commit()
c.close()




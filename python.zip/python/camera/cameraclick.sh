#!/bin/bash

DATE=$(date +"%Y-%m-%d_%H%M")

sudo raspistill -vf -hf -o /var/www/html/campic/$DATE.jpg
sudo python cameradb.py $DATE.jpg


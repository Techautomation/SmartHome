import gtts
from gtts import gTTS

tts=gTTS(text='Fan off!',lang='en',slow=True)
tts.save('fanoff.mp3')


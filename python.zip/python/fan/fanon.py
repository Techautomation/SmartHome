import RPi.GPIO as GPIO
import os
LedPin = 3    # pin3
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.HIGH) # Set LedPin high(+3.3V) to turn on led
print "fan on" # fan on
os.system("sudo python /email1.py 'Fan On' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'Fan-on' &")
os.system("sudo omxplayer /var/www/html/python/fan/fanon.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py fan on &")



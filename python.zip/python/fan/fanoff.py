import RPi.GPIO as GPIO
import os
LedPin = 3    # pin3
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.LOW) # Set LedPin high(+3.3V) to turn on led
print "fan off" # fan off
os.system("sudo python /email1.py 'Fan Off' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'Fan off' &")
os.system("sudo omxplayer /var/www/html/python/fan/fanoff.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py fan off &")




import RPi.GPIO as GPIO
import sys, os
LedPin = 5    # pin3
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.HIGH) # Set LedPin high(+3.3V) to turn on led
print "bulb on" # bulb on
#os.system("sudo omxplayer bulbon.mp3")
os.system("sudo python /email1.py 'bulb-on' &")
os.system("sudo python /var/www/html/python/sms/pysms.py 'bulb-on' &")
os.system("sudo omxplayer /var/www/html/python/bulb/bulbon.mp3 &");
os.system("sudo python ../python/lcd/lcddisplay.py bulb on &");




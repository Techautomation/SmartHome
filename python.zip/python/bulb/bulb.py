import gtts
from gtts import gTTS

tts=gTTS(text='bulb off',lang='en',slow=True)
tts.save('bulboff.mp3')


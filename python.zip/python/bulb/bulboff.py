import RPi.GPIO as GPIO
import os
LedPin = 5    # pin5
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.LOW) # Set LedPin high(+3.3V) to turn on led
print "bulb off" # bulb off
os.system("sudo python /email1.py '# bulb-off' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'bulb-off' &")
os.system("sudo omxplayer /var/www/html/python/bulb/bulboff.mp3 &");
os.system("sudo python ../python/lcd/lcddisplay.py bulb off &");



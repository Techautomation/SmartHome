import requests
import sys
message=sys.argv[1]

url = "https://www.fast2sms.com/dev/bulk"

import requests

url = "https://www.fast2sms.com/dev/bulk"

querystring = {"authorization":"JkwdiCGz2LUmV34KmrVd91eQnU0x8dB9zMwpTvS9fZbm7090WDWJFyInKIcx ","sender_id":"SMHOME","message":message,"language":"english","route":"p","numbers":"9755186485","flash":"0"}

headers = {
    'cache-control': "no-cache"
}

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)






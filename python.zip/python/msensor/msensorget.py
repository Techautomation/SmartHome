#!/usr/bin/python
import RPi.GPIO as GPIO
import time
import os ,sys
import MySQLdb
db=MySQLdb.connect('localhost','hello','','smarthome')
c=db.cursor() 
#GPIO SETUP
channel = 23
GPIO.setmode(GPIO.BCM)
GPIO.setup(channel, GPIO.IN)
 
def callback(channel):
        if GPIO.input(channel):
                print "Water Not Detected!"
		os.system("sudo python ../lcd/lcddisplay.py 'Moisture Senor' 'pump on' &")
		os.system("sudo python ../pump/pumpon.py")
                sql = "INSERT INTO msensordata(data)  \
                VALUES ('low' );"  
                c.execute(sql)
                # Commit your changes in the database
                db.commit()
        else:
                print "Water Detected!"
                os.system("sudo python ../lcd/lcddisplay.py 'Moisture Senor' 'water detected' &")
                sql = "INSERT INTO msensordata(data)  \
                VALUES ('Detected' );"
                c.execute(sql)
                # Commit your changes in the database
                db.commit()
		time.sleep(4)
		os.system("sudo python ../pump/pumpoff.py &")

 
GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)  # let us know when the pin goes HIGH or LOW
GPIO.add_event_callback(channel, callback)  # assign function to GPIO PIN, Run function on change
 
# infinite loop
while True:
        time.sleep(2)

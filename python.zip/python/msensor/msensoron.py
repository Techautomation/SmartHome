import RPi.GPIO as GPIO
import os
LedPin = 11    # pin11
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.HIGH) # Set LedPin high(+3.3V) to turn on led
print "msensor on" # msensor on 
os.system("sudo python /email1.py 'Moisture Sensor On!' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'Moisture Sensor ON!' &")
os.system("sudo omxplayer /var/www/html/python/msensor/msensoron.mp3")
os.system("sudo python ../python/lcd/lcddisplay.py msensor on &")



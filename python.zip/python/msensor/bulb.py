import gtts
from gtts import gTTS

tts=gTTS(text='Moisture Sensor Off!',lang='en',slow=True)
tts.save('msensoroff.mp3')


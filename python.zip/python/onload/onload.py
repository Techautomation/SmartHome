import sys,os
os.system('sudo python /var/www/html/python/lcd/lcddisplay.py "Welcome!!" "@Smarthome" &')
os.system("sudo python /email1.py 'Welcome!! [It Seems That Someone Is Online ]' &")
os.system("sudo python /var/www/html/python/sms/pysms.py 'Some-one Is Online Please Check!'")
os.system('sudo omxplayer /var/www/html/python/onload/onload.mp3 &')


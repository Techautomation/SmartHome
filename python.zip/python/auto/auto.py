import os,sys
os.system('sudo python /var/www/html/python/lcd/lcddisplay.py "[MODE:-]" "Automatic" &')
os.system("sudo python /email1.py 'Set As Auto Mode' &")
os.system("sudo python /var/www/html/python/sms/pysms.py 'Configured as Automatic Mode' &")
os.system('sudo omxplayer /var/www/html/python/auto/auto.mp3 &')


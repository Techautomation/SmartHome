import smtplib
import sys
message = sys.argv[1]


# Establish a secure session with gmail's outgoing SMTP server using your gmail account
server = smtplib.SMTP( "smtp.gmail.com", 587 )

server.starttls()

server.login( 'your email id', 'your gmail password' )

#0 Send text message through SMS gateway of destination number
server.sendmail( 'your email id', 'reciever email id', message )
server.quit()


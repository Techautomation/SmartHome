import sys,os
os.system('sudo python /var/www/html/python/lcd/lcddisplay.py "[MODE:-]" "Mannual" &') 
os.system("sudo python /email1.py 'Home Is Configiured To Mannual Mode' &")
os.system("sudo python /var/www/html/python/sms/pysms.py 'Home is configured as mannual mode'&")
os.system('sudo omxplayer /var/www/html/python/manual/manual.mp3 &')


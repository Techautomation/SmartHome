import RPi.GPIO as GPIO
import os
LedPin = 7    # pin7
GPIO.setmode(GPIO.BOARD)       # Numbers GPIOs by physical location
GPIO.setup(LedPin, GPIO.OUT)   # Set LedPin's mode is output
GPIO.output(LedPin, GPIO.LOW) # Set LedPin high(+3.3V) to turn on led
print "garden light off" # garden light off
os.system("sudo python /email1.py 'Garden Light off' &")
#os.system("sudo python /var/www/html/python/sms/pysms.py 'Garden Light Off' &")
os.system("sudo omxplayer /var/www/html/python/gardenlight/gardenlightoff.mp3")
system("sudo python ../python/lcd/lcddisplay.py gardenlight off &");



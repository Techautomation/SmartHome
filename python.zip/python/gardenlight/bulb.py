import gtts
from gtts import gTTS

tts=gTTS(text='Garden light off!',lang='en',slow=True)
tts.save('gardenlightoff.mp3')

